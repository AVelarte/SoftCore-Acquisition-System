/** \file HAL_rhd2000_config.h
* A brief file description.
* Created on:    2023/10/09
* Last modified: 2023/11/01 10:15:34
*/

#ifndef _RHD2000_CONFIG_H_
#define _RHD2000_CONFIG_H_

#include <stdint.h>
#include "HAL_rhd2000.h"

/*
;-------- <<< Use Configuration Wizard in Context Menu >>> -------------------
*/

//--------------------- RHD2000 Configuration ----------------------------------
// <h>Valores de inicio de los registros del INTAN RHD200
// =======================
//   <o>R00 register <0x00-0xFF>
//   <i> Set ADC configuration and disable fast settle
//   <i> Default: 0xDE
#ifndef  __R00
 #define __R00   0xDE
#endif
//   <o>R01 register <0x00-0xFF>
//   <i> Configure the ADC and MUX for a total ADC sampling rate of 960 kS/s (i.e,32x30kS/s). These values will work fine for slower sapling rates, but power can be minimized by using specific values provided in this datasheet
//   <i> Default: 0x42
#ifndef  __R01
 #define __R01   0x42
#endif
//   <o>R02 register <0x00-0xFF>
//   <i> Configure the ADC and MUX for a total ADC sampling rate of 960 kS/s (i.e,32x30kS/s). These values will work fine for slower sapling rates, but power can be minimized by using specific values provided in this datasheet
//   <i> Default: 0x04
#ifndef  __R02
 #define __R02   0x04
#endif
//   <o>R03 register <0x00-0xFF>
//   <i> Disable temperature sensor and set digout pin to zero
//   <i> Default: 0x00
#ifndef  __R03
 #define __R03   0x00
#endif
//   <o>R04 register <0x00-0xFF>
//   <i> Configure ADC output format and disable DSP offset removal filter. Alternatively, you could set this register to 0x9C to set the enable the DSP and set the cutoff frequency to 1.17 Hz (i.e., 0.00003886x30kS/s), assuming each channel is sampled at 30 kS/s
//   <i> Default: 0xC0
#ifndef  __R04
 #define __R04   0xC0
#endif
//   <o>R05 register <0x00-0xFF>
//   <i> Set up impedance check circuitry. You can set Register 5 to 0x00 if you will not perform impedance testing
//   <i> Default: 0x40
#ifndef  __R05
 #define __R05   0x40
#endif
//   <o>R06 register <0x00-0xFF>
//   <i> Set up impedance check circuitry. You can set Register 5 to 0x00 if you will not perform impedance testing
//   <i> Default: 0x80
#ifndef  __R06
 #define __R06   0x80
#endif
//   <o>R07 register <0x00-0xFF>
//   <i> Set up impedance check circuitry. You can set Register 5 to 0x00 if you will not perform impedance testing
//   <i> Default: 0x00
#ifndef  __R07
 #define __R07   0x00
#endif
//   <o>R08 register <0x00-0xFF>
//   <i> Set upper cutoff frequency of amplifiers to 7.5 kHz
//   <i> Default: 0x16
#ifndef  __R08
 #define __R08   0x16
#endif
//   <o>R09 register <0x00-0xFF>
//   <i> Set upper cutoff frequency of amplifiers to 7.5 kHz
//   <i> Default: 0x80
#ifndef  __R09
 #define __R09   0x80
#endif
//   <o>R10 register <0x00-0xFF>
//   <i> Set upper cutoff frequency of amplifiers to 7.5 kHz
//   <i> Default: 0x17
#ifndef  __R10
 #define __R10   0x17
#endif
//   <o>R11 register <0x00-0xFF>
//   <i> Set upper cutoff frequency of amplifiers to 7.5 kHz
//   <i> Default: 0x80
#ifndef  __R11
 #define __R11   0x80
#endif
//   <o>R12 register <0x00-0xFF>
//   <i> Set lower cutoff frequency of amplifiers to 1.0 Hz
//   <i> Default: 0x2C
#ifndef  __R12
 #define __R12   0x2C
#endif
//   <o>R13 register <0x00-0xFF>
//   <i> Set lower cutoff frequency of amplifiers to 1.0 Hz
//   <i> Default: 0x86
#ifndef  __R13
 #define __R13   0x86
#endif
//   <o>R14 register <0x00-0xFF>
//   <i> Power up amplifier channels 0-15
//   <i> Default: 0xFF
#ifndef  __R14
 #define __R14   0xFF
#endif
//   <o>R15 register <0x00-0xFF>
//   <i> Power up amplifier channels 0-15
//   <i> Default: 0xFF
#ifndef  __R15
 #define __R15   0xFF
#endif
//   <o>R16 register <0x00-0xFF>
//   <i> Power up amplifier channels 16-31
//   <i> Default: 0x00
#ifndef  __R16
 #define __R16   0x00
#endif
//   <o>R17 register <0x00-0xFF>
//   <i> Power up amplifier channels 16-31
//   <i> Default: 0x00
#ifndef  __R17
 #define __R17   0x00
#endif
//   <o>DirectCMD register <0x0000-0xFFFF>
//   <i> Direct command init value
//   <i> Default: 0xE900
#ifndef  __DirectCMD
 #define __DirectCMD   0xE900
#endif
/*
;------------- <<< end of configuration section >>> ---------------------------
*/

/**
 * @var rhd2000_cnfgds
 * 
 * @brief Valores de configuración de los registros del INTAN RHD2000
 *         los valores de esta tabla se han tomado de la inicialicación 
 *         mostrada en la página 36 del datasheet
 */
const rhd2000config_t rhd2000_cnfgds =
{   
    ///< Set ADC configuration and disable fast settle
    .R00 = __R00, 
    ///< Configure the ADC and MUX for a total ADC sampling rate of 960 kS/s (i.e, 32 × 30 kS/s). These values will work fine for slower sampling rates, but power can be minimized by using specific values provided in this datasheet
    .R01 = __R01, 
    .R02 = __R02, 
    ///< Disable temperature sensor and set digout pin to zero
    .R03 = __R03, 
    ///< Configure ADC output format and disable DSP offset removal filter. Alternatively, you could set this register to 0x9C to set the enable the DSP and set the cutoff frequency to 1.17 Hz (i.e., 0.00003886 × 30 kS/s), assuming each channel is sampled at 30 kS/s
    .R04 = __R04,  
    ///<  Set up impedance check circuitry. You can set Register 5 to 0x00 if you will not perform impedance testing
    .R05 = __R05, 
    .R06 = __R06,
    .R07 = __R07,
    ///< Set upper cutoff frequency of amplifiers to 7.5 kHz
    .R08 = __R08,  
    .R09 = __R09,
    .R10 = __R10,
    .R11 = __R11,
    ///< Set lower cutoff frequency of amplifiers to 1.0 Hz
    .R12 = __R12, 
    .R13 = __R13,
    ///< Power up amplifier channels 0-15.
    .R14 = __R14,  
    .R15 = __R15,
    ///< Power down amplifier channels 16-31.
    .R16 = __R16,
    .R17 = __R17,
    ///< Direct command init value
    .DirectCMD = __DirectCMD
};


/**
 * @var rhd2000_cnfg1
 * @brief Valores de configuración de los registros del INTAN RHD2000
 *         esta tabla se utiliza en tareas de test
 */
const rhd2000config_t rhd2000_cnfg1 =
{
    .R00 = 0x11030,
    .R01 = 0x11031,
    .R02 = 0x11032,
    .R03 = 0x11033,
    .R04 = 0x11034,
    .R05 = 0x11035,
    .R06 = 0x11036,
    .R07 = 0x11037,
    .R08 = 0x11038,
    .R09 = 0x11039,
    .R10 = 0x11041,
    .R11 = 0x11042,
    .R12 = 0x11043,
    .R13 = 0x11044,
    .R14 = 0x11045,
    .R15 = 0x11046,
    .R16 = 0x11047,
    .R17 = 0x11048,
    .DirectCMD = 0xE900
};


#endif  /* _RHD2000_CONFIG_H_ */ 
