## Contenidos de esta carpeta:

```c
┆
└─── util
        artyprog.cfg        // Importar para añadrir comandos al menu TOLLS de UV
        djtgcfg.exe         // Utilidada para descargar confiduración a la FPGA
        M1_mi_wrapper.bit   // Fichero de configuración de la FPGA
        M1_mi.mmi           // Organización de la memoria, se utiliza para parchear el .bit
        readme.md
```

## Uso:
#### Configuración de la FPGA:

```
  djtgcfg.exe prog -d Arty -i 0 -f M1_mi_wrapper.bit
```

#### Actualización del ejecutable en .bit:

```
  D:\programs\Xilinx\Vivado\2018.2\settings64.bat
  updatemem --force --meminfo m1_mi.mmi --data ..\ARM\Objects\test_rhd2k_fifo.elf --bit M1_mi_wrapper.bit --proc dummy --out M1_mi_patch.bit
```
