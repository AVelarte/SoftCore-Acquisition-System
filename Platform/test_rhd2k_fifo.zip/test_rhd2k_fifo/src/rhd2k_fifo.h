/** \file rhd2k_fifo_config.h
* A brief file description.
* Created on:    2023/10/22
* Last modified: 2023/10/23 15:25:31
*/

#ifndef _RHD2K_FIFO_CONFIG_H_
#define _RHD2K_FIFO_CONFIG_H_

#include <stdint.h>

typedef struct rhd2k_fifo_struct rhd2k_fifo_t;


/**
 * @brief Crea un objeto rhd2k fifo de tamaño size
 * 
 * @param size Tamaño de la fifo
 * @return rhd2k_fifo_t* 
 * 
 * @note EN la FIFO se almacenan datos de tipo int16_t
 */
rhd2k_fifo_t *rhd2k_fifo_create(uint32_t size);

/**
 * @brief Destruye un objeto rhd2k fifo
 * 
 * @param fifo Puntero al objeto fifo
 */
void rhd2k_fifo_destroy(rhd2k_fifo_t *fifo);


/**
 * @brief Escribe un dato en la fifo
 * 
 * @param fifo Puntero al objeto fifo
 * @param data Dato a escribir
 * @return int 0 si se ha escrito correctamente, -1 si la fifo está llena
 */
int rhd2k_fifo_write(rhd2k_fifo_t *fifo, int16_t data);


/**
 * @brief Lee un dato de la fifo
 * 
 * @param fifo Puntero al objeto fifo
 * @param data Puntero al dato leido
 * @return int 0 si se ha leido correctamente, -1 si la fifo está vacía
 */
int rhd2k_fifo_read(rhd2k_fifo_t *fifo, int16_t *data);


/**
 * @brief Lee un dato de la fifo y lo envía a través de la UART
 * 
 * @param fifo 
 */
void rhd2k_fifo_to_serial(rhd2k_fifo_t *fifo);


/**
 * @brief Comprueba si la fifo está llena
 * 
 * @param fifo Puntero al objeto fifo
 * @return int 1 si la fifo está llena, 0 si no lo está
 */
int rhd2k_fifo_is_full(rhd2k_fifo_t *fifo);


/**
 * @brief Comprueba si la fifo está vacía
 * 
 * @param fifo Puntero al objeto fifo
 * @return int 1 si la fifo está vacía, 0 si no lo está
 */
int rhd2k_fifo_is_empty(rhd2k_fifo_t *fifo);


/**
 * @brief Devuelve el tamaño de la fifo
 * 
 * @param fifo Puntero al objeto fifo
 * @return uint32_t Tamaño de la fifo
 */
uint32_t rhd2k_fifo_get_size(rhd2k_fifo_t *fifo);

#endif  /* _RHD2K_FIFO_CONFIG_H_ */ 
