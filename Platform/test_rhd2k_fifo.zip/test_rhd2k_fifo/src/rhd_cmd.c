/**
 * rhd_cmd.c
 * 
 * 
 * */


#include <stdlib.h>
#include "rhd_cmd.h"
#include "m1_arty7_1062.h"
#include "HAL_ARTYM1_uart.h"
#include <string.h>
#include "shell_commands.h"



// Caracteres que almacena en recepción el buffer
#define SHELL_RX_BUFFER_SIZE (256)
#define SHELL_MAX_ARGS (16)
#define SHELL_PROMT "\n>>>> "

static struct Shell
{
	char rx_buffer[SHELL_RX_BUFFER_SIZE]; //Buffer para almacenar el comando
	size_t rx_index;
}s_shell;

int putcharc_(char character)
{
	putchar_(character);
	return 1;
}

void echo(char c)
{
	if ('\r' == c)
	{
		putchar_('\n');
	}
	else if ('\b' == c)
	{
		putchar_('\b');
		putchar_(' ');
		putchar_('\b');
	}
	else
	{
		putchar_(c);
	}
}

void putstr(const char *str)
{
	for(const char *c = str; *c != '\0'; ++c)
	{
		echo(*c);
	}
}

void reset_buffer(void)
{
	memset(s_shell.rx_buffer, 0, sizeof(s_shell.rx_buffer));
	s_shell.rx_index = 0;
}

void ini_cli(void)
{
	reset_buffer();
	putstr(SHELL_PROMT);
}

void cmd_process(char c)
{
	if (c != '\r')
	{
		return;
	}
	char *argv[SHELL_MAX_ARGS] = {0};
	int argc = 0;

	char *next_arg = NULL;
	for(int i = 0; i < s_shell.rx_index && argc < SHELL_MAX_ARGS; ++i)
	{
		char *const c = &s_shell.rx_buffer[i];
		if(*c == ' ' || *c == '\n' || i == s_shell.rx_index - 1)
		{
			*c = '\0';
			if (next_arg)
			{
				argv[argc++] = next_arg;
				next_arg = NULL;
			}
		}
		else if (!next_arg)
		{
			next_arg = c;
		}
	}

	if (argc >= 1)
	{
		if(strcmp("test", argv[0]) == 0)
		{
			cli_cmd_test(argc, argv);
		}
		else if (strcmp("ini", argv[0]) == 0)
		{
			cli_cmd_ini(argc, argv);
		}
		else if (strcmp("cmd", argv[0]) == 0)
		{
			cli_cmd_directcmd(argc, argv);
		}
		else if(strcmp("loop", argv[0]) == 0){
		    cli_cmd_loop(argc, argv);
		}
		else
		{
			cli_cmd_unknown(argc, argv);
		}
	}
	
	reset_buffer();
	putstr(SHELL_PROMT);
}

inline char getchar_()
{
	uint8_t cr;

	while(UART0->STAT_REG_b.RX_FIFO_Valid_Data == 0);

	cr = (char)(UART0->RX_FIFO);
	echo(cr);

	if(s_shell.rx_index == SHELL_RX_BUFFER_SIZE)
	{
		return cr;
	}

	if (cr == '\b')
	{
		s_shell.rx_buffer[--s_shell.rx_index] = '\0';
		return cr;
	}

	s_shell.rx_buffer[s_shell.rx_index++] = cr;
	return cr;
}

