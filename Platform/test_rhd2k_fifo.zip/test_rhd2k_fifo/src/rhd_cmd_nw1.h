/** \file rhd_cmd.h
 *	 
 * 
 * 
 * */

#ifndef _RHD_CMD_H_
#define _RHD_CMD_H_

#include "m1_arty7_1062.h"

typedef struct rhd_cmd_struct rhd_cmd_t;

/**
 * 	@brief Crea un objeto tipo rhd_cmd de tamamño size
 *   
 * 	@param size Tamaño de la memoria para almacenar el cmd
 * 
 * 	@note se almacenan caracteres de tipo char.
 **/
rhd_cmd_t *rhd_cmd_create(uint32_t size);

/**
 * 	@brief Destruye un objeto de tipo rhd_cmd
 * 	@param cmd puntero al objeto rhd_cmd
 * */
void rhd_cmd_destroy(rhd_cmd_t *cmd);

/**
 * 	@brief Lee de la Fifo del uart y lo pasa al objeto de tipo rhd_cmd
 * 	@param cmd puntero al objeto rhd_cmd
 * */
void uart_read_cmd(rhd_cmd_t *cmd);

/**
 *	@brief Escribe por pantalla los datos del comando recibido
 * 	@param cmd puntero al objeto rhd_cmd
 * */
void uart_write_test(rhd_cmd_t *cmd);

#endif /* _RHD_CMD_H_ */