/**
 * 
 */

#ifndef _CMD_H_
#define _CMD_H_

#include "m1_arty7_1062.h"
#include "main.h"

/**
 * @brief      cli_cmd_ini recoge el comando recibido para la inicializción. En función de los argumentos introducidos por el usuario, se lanza la inicialización por defecto (solo 1 argumento "ini") o se actualizan los registros de configuración y se vuelve a lanzar el proceso de inicialización ("ini conf -RXX") Acepta modificar solo algunos registros, no es necesario listar todos. 
 *
 * @param[in]  argc  The count of arguments
 * @param      argv  The arguments array:
 * 						- Command Identifier (ini)
 * 						- Action to perform (config) (opt.)
 * 						- Register to config (-Rxx) (opt.)
 * 						- Register value in hex (opt.)
 *
 * @return     1 en caso de que la inicialización sea correcta, 0 en caso contrario.
 */
int cli_cmd_ini(int argc, char *argv[]);

/**
 * @brief      cli_cmd_directcmd recoge el comando directo hacia el INTAN. Acepta las distintas acciones en función de los argumentos y el número de los argumentos
 *
 * @param[in]  argc  The count of arguments
 * @param      argv  The arguments array:
 * 						- Command Identifier (cmd)
 * 						- Action to perform (write/read/convert/clear):
 * 						- Write data (opt.)
 * 						- Write/Read address (opt.)
 * 						- Convert channel (opt.)
 *
 * @return    1 en caso de que la inicialización sea correcta, 0 en caso contrario.
 */
int cli_cmd_directcmd(int argc, char *argv[]);

/**
 * @brief      Agrupa todos los comandos para el bucle de conversión de canales en función del número de argumentos. ("loop start") inicial el bucle y ("loop config") permite configurarlo.
 *
 * @param[in]  arg   The argument
 * @param      argv  The arguments array:
 * 						- Command Identifier (loop)
 * 						- Command Action (start/config)
 * 						- Loop configuration (opt.)
 *
 * @return     1 en caso de que la inicialización sea correcta, 0 en caso contrario.
 */
int cli_cmd_loop(int arg, char *argv[]);

/**
 * @brief      Función de test para probar el funcionamiento de la interfaz serie. 
 *
 * @param[in]  argc  The count of arguments
 * @param      argv  The arguments array:
 * 						- Command Identifier (test)
 *
 * @return    1 en caso de que la inicialización sea correcta, 0 en caso contrario.
 */	
int cli_cmd_test(int argc, char *argv[]);

/**
 * @brief      Función que se ejecuta cuando el comando es desconocido.
 *
 * @param[in]  argc  The count of arguments
 * @param      argv  The arguments array
 *
 * @return     1 en caso de que la inicialización sea correcta, 0 en caso contrario.
 */
int cli_cmd_unknown(int argc, char *argv[]);


#endif /* _CMD_H_ */
