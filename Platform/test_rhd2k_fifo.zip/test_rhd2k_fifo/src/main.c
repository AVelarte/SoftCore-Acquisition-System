/*
 * main.c
 *
 *  Last modified: 2023/10/23 15:19:35
 */

#define __MEM_CHK__ 0

#include <stdint.h>
#include "m1_arty7_1062.h"
#include "HAL_systick.h"
#include "HAL_ARTYM1_uart.h"
#include "ARTY_A7_hi.h"
#include "HAL_rhd2000.h"
#include "HAL_rhd2000_config.h"
#include "xil_printf.h"

#include "rhd2k_fifo.h"

#include "rhd_cmd.h"
#include "main.h"
#include "shell_commands.h"

#define RHD2K_FIFO_SIZE 120*1024  //max 248KB (248*1024)
#define RHD_CMD_SIZE 8*128

rhd2k_fifo_t *g_fifo;

g_experiment_params g_cap_params;

void ini_cap_params()
{
	g_cap_params.max_periods_estim = 1000;
	g_cap_params.max_samples_estim = 1000;
	g_cap_params.g_start_cap = 0;
	g_cap_params.g_bsy_cap = 0;
}


int main(void)
{
   
  xil_printf("\n\n>>>> \033[33mCortex M1 running on ARTY A7 FPGA\033[0m\n\n>>>>  build: %s %s\n", __DATE__, __TIME__);

  // Inicializa rhd2k_fifo
  g_fifo=rhd2k_fifo_create(RHD2K_FIFO_SIZE); 
		
	// Inicializa 
	UART0->CTRL_REG_b.Enable_Intr=1;
  // Inicializa perifericos
  // RHD2000 config
  if (Rhd2000Init(&rhd2000_cnfgds))
  {
    LedSetColor(LD1, RED);
  }
  else
  {
    LedSetColor(LD1, GREEN);
  }
  //   Configuración de la conversión periódica
  //     Captura los 16 primeros canales 0x0000FFFFu
  //     Blanking time 25 us (SystemCoreClock / 40000 - 1)
  //     Frecuencia de muestreo 2K (SystemCoreClock / 2000 - 1)
	//	Iniciamos tambien los valores de las samples. 
	ini_cap_params();
  Rhd2000ChLoopConfig( 0x00000Fu,
                      (SystemCoreClock / 40000 - 1),
                      (SystemCoreClock / 2000 - 1));
  
  //    Inicializa GPIO_2
  GPIO_2->GPIO_TRI = 0x01; //  bit 0 como entrada
  //LedSetColor(LD4, GREEN);
  //  Filtra el primer pulso de GPIO_2(0)
  //     sino la simulacion no funciona¿?
//	while (!(GPIO_2->GPIO_DATA & 1))
//  {
//    // empty loop
//  }
//  while ((GPIO_2->GPIO_DATA & 1))
//  {
//    // empty loop
//  }

  // Configura interrupcion de GPIO
  GPIO_2->IP_ISR_b.Channel_1_Interrupt_Status = 1;
  GPIO_2->GIER_b.Global_Interrupt_Enable = 0; // Comenzamos con la interrupción a 0 para que hasta el momento de la captura no se active. 
  GPIO_2->IP_IER_b.Channel_1_Interrupt_Enable = 1;
	


  // habilita interrupciones
  NVIC_EnableIRQ(GPIO2_IRQn);
  NVIC_EnableIRQ(I_PERI_IRQn);   //Habilitamos la interrupción del periférico
	//NVIC_EnableIRQ(I_TX_OVERRUN_IRQn); // Habilitamos la interrupción de la UART de datos
  NVIC_EnableIRQ(UART0_IRQn);
	
	
	//  Inicializa RHD2000
  
  char intan_ini[6]={RHD2000->R40,RHD2000->R41,RHD2000->R42,RHD2000->R43,RHD2000->R44,'\0'};
  xil_printf(">>>>  regs 41->44: %s\n\n",intan_ini);
	

	//Modicicamos la velocidad de la interfaz de datos
	RHD2000->TX_CTL_b.T_bit = 42; //?

   LedSetColor(LD5, OFF);
		

	char c;
	ini_cli();
	
  while (1)
  { 
		//LedSetColor(LD5, GREEN);
		LedSetColor(LD3, OFF);
		//LedSetColor(LD2, OFF);
		
		LedSetColor(LD6, OFF);
		LedSetColor(LD7, OFF);

		// Leemos comando
		c = getchar_();
		cmd_process(c);
		
		if(g_cap_params.g_start_cap == 1)
		{
			putstr("Start Capture \n");
			//Habilitamos la interrupción del GPIO
			GPIO_2->GIER_b.Global_Interrupt_Enable = 1;
			g_cap_params.g_start_cap = 0;
			g_cap_params.g_bsy_cap = 1;
			LedSetColor(LD5, BLUE); 
			
			// Bloqueamos hasta que termine la captura
			while(g_cap_params.g_bsy_cap == 1)
			{
				//Empty loop
				//putstr("a");
			}
			LedSetColor(LD5, OFF);
		}

				
    /*
    {
      int16_t data;
      (void)rhd2k_fifo_read(g_fifo, &data);
      puthalfword(data);
    }
    */
		
    // envía datos de la fifo por el puerto serie (si es posible)
    //rhd2k_fifo_to_serial(g_fifo); 
  }
}

/**
 * @section Interrupciones
 * 
 */

/**
 * @brief Interrupción de GPIO_2, se activa con cada flanco up/down de GPIO_2(0)
 * 
 */
void GPIO2_Handler()
{
  // deshabilita interrupcion
  GPIO_2->GIER_b.Global_Interrupt_Enable = 0;
  // habilita la captura en bucle
  RHD2000->Status_b.CH_LOOP=1;
	//xil_printf("\n\n>>>> Trigger");
	putstr("New Stimuli \n");
	LedToggle(LD5);
	LedSetColor(LD2, GREEN);
}

/**
 * @brief Interrupción de RHD2000, hay que verifica el tipo de interrupción que se produce. (Por nuevo dato directo o por fin de bucle de conversión
 * 
 */
void RHD2000_PERI_Handler()
{ 
	if(RHD2000->Status_b.END_CH == 1)
	{
		static uint16_t samples_estim=0;       // muestras en cada estimulación
		//const uint16_t max_samples_estim = 1000; // MAX #muestras en cada estimulación
		static uint16_t periods_estim=0;       // periodos de estimulación
		//const uint16_t max_periods_estim = 1000; // MAX #periodos de estimulación
		
		LedSetColor(LD6, GREEN);
		// Escribe los valores de las muestras en la FIFO global
//		{
//			uint32_t channels = RHD2000->ChSel;
//			int16_t *p_ch = (int16_t *)&RHD2000->ChR_reg0;
//			while (channels != 0)
//			{
//					if (channels & 0x1)
//					{
//							while(rhd2k_fifo_is_full(g_fifo))
//							{
//								// empty loop
//								LedSetColor(LD4, GREEN);
//							}
//							LedSetColor(LD7, GREEN);
//							(void)rhd2k_fifo_write(g_fifo, *p_ch);
//					}
//					p_ch++;
//					channels >>= 1;
//			}
//		}  
		
	 //LedSetColor(LD5, OFF);
		samples_estim++;
		
		if (samples_estim == g_cap_params.max_samples_estim)
		{   
			samples_estim = 0;
			if (periods_estim < g_cap_params.max_periods_estim)
			{ periods_estim++; 
				//  Preparación para la siguiente estimulación
				//    limpia interrupcion pendiente y habilita interrupción de GPIO
				GPIO_2->IP_ISR_b.Channel_1_Interrupt_Status = 1;  
				GPIO_2->GIER_b.Global_Interrupt_Enable = 1;
			}
			else
			{
				// Si es el último periodo de estimulación
				GPIO_2->GIER_b.Global_Interrupt_Enable = 0; // Dejas deshabilitada la interrupción (esto ya estaría por defecto)
				//volvemos a poner los contadores a 0
				samples_estim = 0;
				periods_estim = 0;
				putstr("Done \n");
				ini_cli(); //Reiniciamos el cli para evitar las posibles entradas del usuario durante este rato.
				g_cap_params.g_bsy_cap = 0;
			}
			// deshabilita la captura en bucle
			Rhd2000ChLoopStop();
		}
		// limpia el flag de interrupcion
		Rhd2000ChLoopIFcln();
	}
	else if(RHD2000->Status_b.NEW_DATA_R == 1)
	{
		RHD2000->Status_b.NEW_DATA_R = 0;
	}
}


/**
 * @brief Interrupción de UART0, se activa cuando la fifo de salida esta vacia, 
 *     o la de entrada llena.
 * 
 */
void UART0_Handler()
{
  // Interrupción de transmisión si la FIFO de TX está vacía
  if ( UART0->STAT_REG_b.TX_FIFO_Empty == 1 )
  {
    Rhd2000PutChnls_noblck();
  }
	else if( UART0->STAT_REG_b.RX_FIFO_Full == 1)
	{
		putstr("FIFOFULL");
	}
}
