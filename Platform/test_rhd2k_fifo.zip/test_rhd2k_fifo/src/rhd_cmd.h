/** \file rhd_cmd.h
 *	 
 * 
 * 
 * */

#ifndef _RHD_CMD_H_
#define _RHD_CMD_H_

#include "m1_arty7_1062.h"

/**
 *	@brief Envía un carácter al puerto serie y devuelve confirmación
 * 	@return 1
 **/
int putcharc_(char character);

/**
 * 	@brief Envía un echo al puerto serie para su lectura desde el PC
 * 	@param c caracter que se devuelve
 */
void echo(char c);

void cmd_process(char c);

/**
 * 	@brief Lee un carácter de la fifo RX del buffer
 * 
 * 	@return cr char con el carácter leido.
 **/
char getchar_();

/**
 * @brief      Escribe en pantantalla una determinada string.
 *
 * @param[in]  *str   Pointer to the string
 */
void putstr(const char *str);

/**
 * @brief      Vacía el buffer que recibe los carácteres del puerto serie.
 */
void reset_buffer();

/**
 * @brief      Inicializa la interfaz de linea de comando. 
 */
void ini_cli();

#endif /* _RHD_CMD_H_ */