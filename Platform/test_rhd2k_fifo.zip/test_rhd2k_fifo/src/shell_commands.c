#include "rhd_cmd.h"
#include "shell_commands.h"

#include "HAL_rhd2000.h"
#include "m1_arty7_1062.h"
#include "ARTY_A7_hi.h"
#include "rhd2k_fifo.h"

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <inttypes.h>

#define ARRAY_SIZE(arr) (sizeof(arr) / sizeof(arr[0]))
	
extern rhd2k_fifo_t *g_fifo;
extern g_experiment_params g_cap_params;

// Cmd para autoinicializacíón. En función de los argumentos es una normal o es una modificada. 
int cli_cmd_ini(int argc, char *argv[])
{
  if(strcmp("conf", argv[1]) == 0 && argc>2)
  {
    // Sobreescribe los valores de la inicialización con los que se pasan por comando y lanza la inicialización de esta forma.
		for(short i = 2; i < argc; i=i+2)
		{
			putstr("change conf");
			char *endptr;
			uint16_t reg = strtoimax(argv[i+1], &endptr, 10);
			if(strcmp("-R00", argv[i])==0) 			{RHD2000->R00 = reg;}
			else if(strcmp("-R01", argv[i])==0)	{RHD2000->R01 = reg;}
			else if(strcmp("-R02", argv[i])==0) {RHD2000->R02 = reg;}
			else if(strcmp("-R03", argv[i])==0) {RHD2000->R03 = reg;}
			else if(strcmp("-R04", argv[i])==0) {RHD2000->R04 = reg;}
			else if(strcmp("-R05", argv[i])==0) {RHD2000->R05 = reg;}
			else if(strcmp("-R06", argv[i])==0) {RHD2000->R06 = reg;}
			else if(strcmp("-R07", argv[i])==0) {RHD2000->R07 = reg;}
			else if(strcmp("-R08", argv[i])==0) {RHD2000->R08 = reg;}
			else if(strcmp("-R09", argv[i])==0) {RHD2000->R09 = reg;}
			else if(strcmp("-R10", argv[i])==0) {RHD2000->R10 = reg;}
			else if(strcmp("-R11", argv[i])==0) {RHD2000->R11 = reg;}
			else if(strcmp("-R12", argv[i])==0) {RHD2000->R12 = reg;}
			else if(strcmp("-R13", argv[i])==0) {RHD2000->R13 = reg;}
			else if(strcmp("-R14", argv[i])==0) {RHD2000->R14 = reg;}
			else if(strcmp("-R15", argv[i])==0) {RHD2000->R15 = reg;}
			else if(strcmp("-R16", argv[i])==0) {RHD2000->R16 = reg;}
			else if(strcmp("-R17", argv[i])==0) {RHD2000->R17 = reg;}
		}
  }
	
	// Utiliza la configuración por defecto si no se dice lo contrario en el comando. Si el comando llevaba configuración se modifica en el bucle de arriba. 
    RHD2000->Status_b.START_INI=1;
    LedSetColor(LD1, RED);
		while(RHD2000->Status_b.INI)
		{
			//Empty Loop
		}	
    LedSetColor(LD1, RED);
		if (RHD2000->R40=='I' && RHD2000->R41=='N' && RHD2000->R42=='T' && RHD2000->R43=='A' && RHD2000->R44=='N')
    {
			  putstr("\n Done. \n");
        return 1;
    }
	
  return 0;
}

// Cmd para comando directo
int cli_cmd_directcmd(int argc, char *argv[])
{
  // Esperamos 3 argumentos
  // 1. Nombre del comando (cmd)
  // 2. Acción (Write, read, calibrate, convert, clear)
  // 3. Canal o registro sobre el que se va a actuar (no en todos)
  // 4. Datos a escribir (solo en el write)
  if (argc < 2)
  {
    putstr("Número de argumentos invalido.");
    putstr("\n");
    return 0;
  }

  if (strcmp("write", argv[1]) == 0)
  {
    char *wrendptr;
    int16_t reg = strtoimax(argv[2], &wrendptr, 10);
    if (reg > 17)
    {
      putstr("\n");
      putstr("Registro seleccionado inválido");
      putstr("\n");

      return 0;
    }
    char *wrdendptr;
    int16_t data = strtoimax(argv[3], &wrdendptr, 10);
    char result[7];
    int16_t tmp = (10<<14) + (reg<<8) + (data);
    if (Rhd2000Cmnd(tmp) == ((0xFF<<8) + data))
    {
      putstr("\n");
      putstr("Done");
      return 1;
    }
  }
  else if (strcmp("read", argv[1]) == 0)
  {
    char *endptr;
    int16_t reg = strtoimax(argv[2], &endptr, 10);
    char result[7];
    int16_t tmp =  (11<<14) + (reg<<8);

		// To-Do: En función de los datos del registro plotee el carácter en lugar del número (reg 40-44 i.e) ¿Hacerlo directamente en pc?
    sprintf(result, "%d", Rhd2000Cmnd(tmp));
    putstr(result);
    putstr("\n");
    return 1;
  }
  else if(strcmp("calibrate", argv[1]) == 0)
  {
		// Esto es solo el calibrate, no puedes lanzarlo como si nada, necesitas seguirlo de otros comandos.
		int16_t tmp = Rhd2000Cmnd(0x5500);
		char to_plot[7];
    sprintf(to_plot, "%d", tmp);
    putstr(to_plot);
    return 1;
  }
  else if (strcmp("convert", argv[1]) == 0)
  {
    // To-do: Cerrar solo a los canales que se pueden convertir. 
    char *endptr;
    int16_t channel = strtoimax(argv[3], &endptr, 10);
		char to_plot[7];
    sprintf(to_plot, "%d", Rhd2000Cmnd(channel<<8));
    putstr(to_plot);
		return 1;
				// Hay retraso de 3 comandos, por eso salta error. La comprobación no se puede hacer aquí
//    if (channel < 16)
//    {

//			return 1;
//    }
  }
  else if (strcmp("clear", argv[1]) == 0)
  {
		uint16_t response = Rhd2000Cmnd(0x6A00);
		char to_plot[7];
    sprintf(to_plot, "%d", response);
    putstr(to_plot);
		return 1;
		// Hay retraso de 3 comandos, por eso salta error. La comprobación no se puede hacer aquí
//    if( response == 0 || response == 0x8000)
//    {
//      return 1;
//    }
  }
  putstr("\n");
  putstr("Error en el comando. \n");
  return 0;
}

// Cmd para configurar loop
int cli_cmd_loop(int argc, char *argv[])
{
  if(argc > 2)
  {
    //Mirar si es config
    if (strcmp("config", argv[1]) == 0)
    {
      uint32_t channels = RHD2000->ChSel;
      uint16_t blanking = RHD2000->TimBlnk;
      uint16_t sampling = RHD2000->TimSmpl;


      for(short i = 2; i < argc; i = i+2)
      {
        if (strcmp("-ch", argv[i]) == 0)
        {
          char *endptr;
          // Hay que pasarlo en hex con el 0x delante
          channels = strtoimax(argv[i+1], &endptr, 0);          
        }
        else if (strcmp("-blnk", argv[i]) == 0)
        {
					// Hay que pasarlo en us
          char *endptr;
					uint16_t blank = strtoimax(argv[i+1], &endptr, 10);
					if(blank == 0)
					{
						blanking = 0;
					}
					else
					{
						blanking = blank * SystemCoreClock/1000000 -1;			
					}
        }
        else if (strcmp("-fs", argv[i]) == 0)
        {
          char *endptr;
          // Hay que pasarlo en Hz
          sampling = (SystemCoreClock / strtoimax(argv[i+1], &endptr, 10) - 1);
        }
				else if (strcmp("-nest", argv[i]) == 0)
				{
					char *endptr;
					// Hay que pasar el número de estimulaciones que va a haber hasta detener el periodo de captura
					g_cap_params.max_periods_estim = strtoimax(argv[i+1], &endptr, 10);
				}
				else if (strcmp("-Tc", argv[i]) == 0)
				{
					char *endptr;
					// Hay que pasarlo en ms
					uint16_t tc = strtoimax(argv[i+1], &endptr, 10);
					float tmp = (SystemCoreClock/(1000*((float)sampling + 1)));
					g_cap_params.max_samples_estim = tc*tmp;					
				}
        else
        {
          return 0;
        }
      }
        
      Rhd2000ChLoopConfig(channels, blanking, sampling);
      if ((RHD2000->ChSel == channels) && (RHD2000->TimBlnk == blanking) &&
        (RHD2000->TimSmpl == sampling))
      {
				putstr("New Configuration: \n");
				
				putstr("   - Channels No.: ");
				char b[7];
				sprintf(b, "%d", channels);
				putstr(b);
				
				putstr("\n   - Blanking [Tclk]: ");
				sprintf(b, "%d", blanking);
				putstr(b);
				
				putstr("\n   - Sample rate [Tclk]: ");
				sprintf(b, "%d", sampling);
				putstr(b);
				
				putstr("\n   - Stimuli No.: ");
				sprintf(b, "%d", g_cap_params.max_periods_estim);
				putstr(b);
				
				putstr("\n   - Capture time per Stimuli [Tclk]: ");
				sprintf(b, "%d", g_cap_params.max_samples_estim);
				putstr(b);
				
        putstr("\n Done. \n");
        return 1;
      }
    }
  }
  else if (strcmp("start", argv[1]) == 0)
  {
    //Rhd2000ChLoopStart();
		g_cap_params.g_start_cap = 1; // Aquí igual habría que meter algún semaforo porque se podría dar el caso de que accedieran a la vez. 		
		return 1;
  }
  putstr("\n Error. \n");
  return 0;
}

// Cmd Test
int cli_cmd_test(int argc, char *argv[]) 
{
  putstr(">>>> Cortex M1 running on ARTY A7 FPGA \n");
  return 1;
}

int cli_cmd_unknown(int argc, char *argv[])
{
  putstr("Comando desconocido: ");
  putstr(argv[0]);
  putstr("\n");
  return 1;
}
