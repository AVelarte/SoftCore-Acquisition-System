
#include <stdint.h>

#ifndef MAIN_H
#define MAIN_H
typedef volatile struct
{
	uint16_t max_samples_estim;
	uint16_t max_periods_estim;
	short g_start_cap;
	short g_bsy_cap;
} g_experiment_params;

#endif