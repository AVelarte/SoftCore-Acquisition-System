/**
 * rhd_cmd.c
 * 
 * 
 * */


#include <stdlib.h>
#include "rhd_cmd.h"
#include "m1_arty7_1062.h"
#include "xil_printf.h"


struct rhd_cmd_struct
{
	uint32_t size;
	uint32_t cmd_len;
	char *data;
};

rhd_cmd_t *rhd_cmd_create(uint32_t size)
{
	rhd_cmd_t *cmd = (rhd_cmd_t *)malloc(sizeof(rhd_cmd_t));
	if(cmd == NULL)
	{
		return NULL;
	}
	cmd->size = size;
	cmd->cmd_len = 0;
	cmd->data = (char *)malloc(size);
	if (cmd == NULL)
	{
		free(cmd);
		return NULL;
	}
	return cmd;
}

void rhd_cmd_destroy(rhd_cmd_t *cmd)
{
	free(cmd->data);
	free(cmd);
}

inline void uart_read_cmd(rhd_cmd_t *cmd)
{
	uint32_t cmd_len = 0;
	uint32_t cmd_int = 0;
	cmd->data[cmd_len] = '\0';

	if((cmd->data[cmd_len] != '\n'))
	{
		cmd_len ++;
		cmd_int = (UART0->RX_FIFO) & 0xFF;
		cmd->data[cmd_len] = (char)cmd_int;
		xil_printf("%s",cmd->data[cmd_len]);
	}
	cmd->data[cmd_len] = '\0';
	cmd->cmd_len= cmd_len;
}

inline void uart_write_test(rhd_cmd_t *cmd)
{
	char cmd_to_write[cmd->cmd_len];
	
	for(short i  =0; i <= cmd->cmd_len; i++)
	{
		cmd_to_write[i] = cmd->data[i];
	}
	
	xil_printf(">>>>  Received cmd: %s\n\n", cmd_to_write);
}
