/** \file rhd2k_fifo_private.h
* A brief file description.
* Created on:    2023/10/22
* Last modified: 2023/10/22 18:14:38
*/

#ifndef _RHD2K_FIFO_H_
#define _RHD2K_FIFO_H_

#include <stdint.h>
#include "rhd2k_fifo.h"

struct rhd2k_fifo_struct {
    uint32_t size;
    uint32_t read_indx;
    uint32_t write_indx;
    uint16_t *buf;
};

#endif  /* _RHD2K_FIFO_H_ */ 
