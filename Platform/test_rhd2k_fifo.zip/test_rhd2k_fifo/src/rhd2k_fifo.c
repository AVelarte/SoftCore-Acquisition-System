/** \file rhd2k_fifo.c
 * A brief file description.
 * Created on:    2023/10/22
 * Last modified: 2023/10/23 15:41:22
 */
#include <stdlib.h>
#include "rhd2k_fifo.h"
#include "m1_arty7_1062.h"

// extern int16_t f_buf[];

struct rhd2k_fifo_struct
{
    uint32_t size;
    uint32_t read_indx;
    uint32_t write_indx;
    int16_t *data;
};

rhd2k_fifo_t *rhd2k_fifo_create(uint32_t size)
{
    rhd2k_fifo_t *fifo = (rhd2k_fifo_t *)malloc(sizeof(rhd2k_fifo_t));
    if (fifo == NULL)
    {
        return NULL;
    }
    fifo->size = size;    
    // fifo->data=f_buf;
    fifo->read_indx = 0;
    fifo->write_indx = 0;
    fifo->data = (int16_t *)malloc(size * 2);
    if (fifo->data == NULL)
    {
        free(fifo);
        return NULL;
    }

    return fifo;
}

void rhd2k_fifo_destroy(rhd2k_fifo_t *fifo)
{
    free(fifo->data);
    free(fifo);
}

inline int rhd2k_fifo_write(rhd2k_fifo_t *fifo, int16_t data)
{
    /*
       if (rhd2k_fifo_is_full(fifo)) {
           return -1;
       }
     */
    fifo->data[fifo->write_indx] = data;
    fifo->write_indx = (fifo->write_indx + 1);
    if (fifo->write_indx >= fifo->size)
    {
        fifo->write_indx = 0;
    }
    return 0;
}

inline int rhd2k_fifo_read(rhd2k_fifo_t *fifo, int16_t *data)
{
    /*
      if (rhd2k_fifo_is_empty(fifo)) {
          return -1;
      }
    */
    *data = fifo->data[fifo->read_indx];
    fifo->read_indx = (fifo->read_indx + 1);
    if (fifo->read_indx >= fifo->size)
    {
        fifo->read_indx = 0;
    }
    return 0;
}

inline void rhd2k_fifo_to_serial(rhd2k_fifo_t *fifo)
{
    while (!rhd2k_fifo_is_empty(fifo))
    {
        uint8_t *p_data = (uint8_t *)&fifo->data[fifo->read_indx];
        while (UART0->STAT_REG_b.TX_FIFO_Full)
        {
            // empty loop
        }
        UART0->TX_FIFO = p_data[0];
        while (UART0->STAT_REG_b.TX_FIFO_Full)
        {
            // empty loop
        }
        UART0->TX_FIFO = p_data[1];
        fifo->read_indx = (fifo->read_indx + 1);
        if (fifo->read_indx >= fifo->size)
        {
            fifo->read_indx = 0;
        }
    }
}

inline int rhd2k_fifo_is_full(rhd2k_fifo_t *fifo)
{
    uint32_t next_write_indx = (fifo->write_indx + 1);
    if (next_write_indx >= fifo->size)
    {
        next_write_indx = 0;
    }
    return (next_write_indx == fifo->read_indx);
}

inline int rhd2k_fifo_is_empty(rhd2k_fifo_t *fifo)
{
    return fifo->read_indx == fifo->write_indx;
}

inline uint32_t rhd2k_fifo_get_size(rhd2k_fifo_t *fifo)
{
    return fifo->size;
}
