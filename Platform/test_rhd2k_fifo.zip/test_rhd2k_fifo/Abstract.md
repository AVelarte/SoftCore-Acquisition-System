### Test Intan RHD2000
- Este código realiza las siguientes funciones:
  - Inicializa el INTAN RHD
  - Configura las interrupciones
  - Incluye una CLI para comunicarse con la plataforma y controlarla desde el ordenador. 
  